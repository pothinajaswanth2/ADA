/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <stack>
#include <locale>
#include <algorithm>
using namespace std;

int preced(char ch){
    if(ch == '+' || ch == '-'){
        return 1;
    }
    else if(ch == '*' || ch == '/'){
        return 2;
    }
    else if(ch == '^'){
        return 3;
    }
    else{
        return 0;
    }
}

string inToPost(string infix){
    stack<char> stk;
    stk.push('#');
    string postfix = "";
    string :: iterator it;
    
    for(it = infix.begin(); it!=infix.end(); it++) {
        
        if(isalnum(char (*it)))
        postfix += *it;
        else if(*it == '(')
        stk.push('(');
        else if(*it == '^')
        stk.push('^');
        else if(*it == ')')
        {
            while(stk.top() != '#' && stk.top() != '('){
                postfix += stk.top();
                stk.pop();
            }
            stk.pop();
        }else{
            if(preced(*it) > preced(stk.top()))
            stk.push(*it);
            else{
                while(stk.top() != '#' && preced(*it) <= preced(stk.top())) {
               postfix += stk.top();    //store and pop until higher precedence is found
               stk.pop();
            }
            stk.push(*it);
        }
        
    }
    
}
    while(stk.top() != '#'){
    postfix += stk.top();
    stk.pop();
    }
    return postfix;
}
 string inToPre(string infix){
     string prefix;
     reverse(infix.begin(), infix.end());
     string::iterator it;
     for(it = infix.begin(); it != infix.end(); it++){
         if(*it == '(')
         *it = ')';
         else if(*it == ')')
          *it ='(';
          
     }
     prefix = inToPost(infix);
     reverse(prefix.begin(), prefix.end());
     return prefix;
 }
int main(){
    char str[15];
    
    cout<<"enter the infix string "<<endl;
    cin >> str;
    cout<<" prefix form is "<< inToPre(str)<< endl;

    
}